#ifndef _BOOLEANS_H_
#define _BOOLEANS_H_

/*
 * @Author: angelini.mattia
 * @StudentCode: 502688
 */

#define TRUE  1
#define FALSE 0

typedef enum { false, true } bool;

#endif /* _BOOLEANS_H_ */
